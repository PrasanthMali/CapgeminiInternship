import React from 'react';

function HelloComponent() {
    let name= 'Avinash';
        return (
            <div >
                <h1 style={{color:"rosybrown"}}>Hello {name}</h1>
            </div>
        )
}
export default HelloComponent;