import React from 'react'
class LoginComponent extends React.Component {
 
    render() {
      return (
          <div>
              <h2>Login Form</h2>
          </div>
      );
 
    }
 
}
 
export default LoginComponent;