import React, {Component} from 'react';
 
class RegisterComponent extends Component {
 
    render() {
      return (
          <div>
              <h2>Register Form</h2>
          </div>
      );
 
    }
 
}
 
export default RegisterComponent;