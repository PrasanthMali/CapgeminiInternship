import React from 'react';

export default function UserGreeting() {
    return (
        <h2>Welcome Back!</h2>
    );
}