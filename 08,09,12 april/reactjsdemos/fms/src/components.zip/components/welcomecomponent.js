import React from 'react';

class WelcomeComponent extends React.Component {
    render(){
        return (
            <div>
                <h1>Welcome Component</h1>
            </div>
        )
    }
}
export default WelcomeComponent;