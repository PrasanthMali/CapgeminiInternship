import React from 'react';

export default function GuestGreeting() {
    return (
        <h2>Please Sign in!</h2>
    );
}